# Federated-Averaging
A simulation of federated learning setting and implementation of FedAvg

Modify parameters in simulator.py and run it.

Data are partitioned Non-IID and unbalanced.
